public interface StudentInterface {
	public void viewAllCourses ();
	public void viewAllNotFullCourses ();
	public void registerForCourse (String courseName, int section);
	public void withdrawFromCourse (String courseName);
	public void viewMyCourses ();
}
