public class User {
	protected String username;
	protected String password;
	protected String firstName;
	protected String lastName;
}
